package com.example.shopmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.shopmanagement.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

}