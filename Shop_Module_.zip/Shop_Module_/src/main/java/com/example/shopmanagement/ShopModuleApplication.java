package com.example.shopmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopModuleApplication.class, args);
	}

}
