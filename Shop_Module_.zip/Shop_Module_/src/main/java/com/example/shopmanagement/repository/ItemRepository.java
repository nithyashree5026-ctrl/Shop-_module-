package com.example.shopmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.shopmanagement.entity.Item;

public interface ItemRepository extends JpaRepository<Item, Long> {

}