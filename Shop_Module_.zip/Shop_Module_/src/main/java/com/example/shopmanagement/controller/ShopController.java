package com.example.shopmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.shopmanagement.entity.*;
import com.example.shopmanagement.service.ShopService;

@RestController
@RequestMapping("/shop")
public class ShopController {

    @Autowired
    private ShopService shopService;

    @PostMapping("/add")
    public Shop addShop(@RequestBody Shop shop) {
        return shopService.addShop(shop);
    }

    @PutMapping("/update")
    public Shop updateShop(@RequestBody Shop shop) {
        return shopService.updateShop(shop);
    }

    @GetMapping("/{id}")
    public Shop searchShopById(@PathVariable Long id) {
        return shopService.searchShopById(id);
    }

    @DeleteMapping("/delete/{id}")
    public Boolean deleteShop(@PathVariable Long id) {
        return shopService.deleteShop(id);
    }

    @PostMapping("/employee/add")
    public Boolean addEmployee(@RequestBody Employee employee) {
        return shopService.addEmployee(employee);
    }

    @PutMapping("/employee/update")
    public Boolean updateEmployee(@RequestBody Employee employee) {
        return shopService.updateEmployee(employee);
    }

    @PostMapping("/item/add")
    public Item addItem(@RequestBody Item item) {
        return shopService.addItem(item);
    }
}