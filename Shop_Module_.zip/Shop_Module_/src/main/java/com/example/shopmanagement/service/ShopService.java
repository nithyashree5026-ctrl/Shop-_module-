package com.example.shopmanagement.service;

import com.example.shopmanagement.entity.*;

public interface ShopService {

    Shop addShop(Shop shop);

    Shop updateShop(Shop shop);

    Shop searchShopById(Long id);

    Boolean deleteShop(Long id);

    Boolean addEmployee(Employee employee);

    Boolean updateEmployee(Employee employee);

    Item addItem(Item item);
}