package com.example.shopmanagement.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.shopmanagement.entity.*;
import com.example.shopmanagement.repository.*;
import com.example.shopmanagement.service.ShopService;

@Service
public class ShopServiceImpl implements ShopService {

    @Autowired
    private ShopRepository shopRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private ItemRepository itemRepository;

    @Override
    public Shop addShop(Shop shop) {
        return shopRepository.save(shop);
    }

    @Override
    public Shop updateShop(Shop shop) {
        return shopRepository.save(shop);
    }

    @Override
    public Shop searchShopById(Long id) {
        return shopRepository.findById(id).orElse(null);
    }

    @Override
    public Boolean deleteShop(Long id) {

        if(shopRepository.existsById(id)) {
            shopRepository.deleteById(id);
            return true;
        }

        return false;
    }

    @Override
    public Boolean addEmployee(Employee employee) {

        employeeRepository.save(employee);
        return true;
    }

    @Override
    public Boolean updateEmployee(Employee employee) {

        employeeRepository.save(employee);
        return true;
    }

    @Override
    public Item addItem(Item item) {
        return itemRepository.save(item);
    }
}